-- Setup default values.
PlayerMovement.lastArmorUnitPath = ""
PlayerMovement.lastArmorUnit = nil

local material_defaults = {
	bump_normal_texture = {
		[2] = Idstring("units/payday2/characters/shared_textures/vest_small_nm"),
		[3] = Idstring("units/payday2/characters/shared_textures/vest_big_nm")
	},
	diffuse_layer1_texture = Idstring("units/payday2_cash/safes/default/base_gradient/base_default_df"),
	diffuse_layer2_texture = Idstring("units/payday2_cash/safes/default/pattern_gradient/gradient_default_df"),
	diffuse_layer0_texture = Idstring("units/payday2_cash/safes/default/pattern/pattern_default_df"),
	diffuse_layer3_texture = Idstring("units/payday2_cash/safes/default/sticker/sticker_default_df")
}

local material_textures = {
	pattern = "diffuse_layer0_texture",
	pattern_gradient = "diffuse_layer2_texture",
	normal_map = "bump_normal_texture",
	sticker = "diffuse_layer3_texture",
	base_gradient = "diffuse_layer1_texture"
}

local material_variables = {
	cubemap_pattern_control = "cubemap_pattern_control",
	pattern_pos = "pattern_pos",
	uv_scale = "uv_scale",
	uv_offset_rot = "uv_offset_rot",
	pattern_tweak = "pattern_tweak"
}

local fps_armor = "units/legendary_armour/armor_skins/fps_armor_arms/fps_armor_arms"
local fps_armor_cc = "units/legendary_armour/armor_skins/fps_armor_arms/fps_armor_arms_cc"

function PlayerMovement:_apply_skin( cosmetic_data, armor_level )
	local unit = EDAH.fancy_fps_armor_unit
	unit:set_material_config( Idstring( fps_armor_cc ), true )

	local initial_materials = unit:get_objects_by_type(Idstring("material"))
	local materials = {}

	for _, m in ipairs(initial_materials) do
		if m:variable_exists(Idstring("wear_tear_value")) then
			materials[m:key()] = m
		end
	end

	local textures = {}

	for _, material in pairs(materials) do
		for key, variable in pairs(material_variables) do
			base_variable = cosmetic_data[key]

			if base_variable then
				material:set_variable(Idstring(variable), tweak_data.economy:get_armor_based_value(base_variable, armor_level))
			end
		end

		for key, material_texture in pairs(material_textures) do
			base_texture = cosmetic_data[key]

			if base_texture then
				base_texture = tweak_data.economy:get_armor_based_value(base_texture, armor_level)
				texture_key = base_texture and base_texture:key()

				if texture_key then
					textures[texture_key] = textures[texture_key] or {
						applied = false,
						ready = false,
						name = base_texture
					}

					if type(textures[texture_key].name) == "string" then
						textures[texture_key].name = Idstring(textures[texture_key].name)
					end
				end
			end
		end
	end

	if not self._textures then
		self._textures = {}
	end

	for key, old_texture in pairs(self._textures) do
		if not textures[key] and not old_texture.applied and old_texture.reqeusted then
			TextureCache:unretrieve(old_texture.name)
		end
	end

	self._textures = textures

	for tex_key, texture_data in pairs(self._textures) do
		if not texture_data.ready then
			if DB:has(Idstring("texture"), texture_data.name) then
				TextureCache:request(texture_data.name, "normal", texture_load_result_clbk, 90)

				texture_data.reqeusted = true
			else
				Application:error("[MenuArmourBase:_apply_cosmetics] Armour cosmetics tried to use no-existing texture!", "texture", texture_data.name)
			end

			texture_data.ready = true
		end
	end

	local p_type, base_texture, new_texture = nil

	for _, material in pairs(materials) do
		for key, material_texture in pairs(material_textures) do
			base_texture = tweak_data.economy:get_armor_based_value(cosmetic_data[key], armor_level)
			new_texture = base_texture or tweak_data.economy:get_armor_based_value(material_defaults[material_texture], armor_level)

			if type(new_texture) == "string" then
				new_texture = Idstring(new_texture)
			end

			if new_texture and alive(material) then
				Application:set_material_texture(material, Idstring(material_texture), new_texture, Idstring("normal"))
			end
		end
	end

	for tex_id, texture_data in pairs(self._textures) do
		if not texture_data.applied then
			texture_data.applied = true

			if texture_data.requested then
				TextureCache:unretrieve(texture_data.name)
			end
		end
	end
end

function PlayerMovement:_attach_fps_default_armour( camera_unit, armor_level, skin_data )
	-- If we're higher than level 5 then we have arm armour.
	--[[
	local bool = true
	for unit_id, unit_data in pairs(camera_unit:spawn_manager():spawned_units()) do
		local num = string.find(unit_id, "char_mesh")
		if num and num>=0 then
			--bool = false
			--break
		end
	end
	]]
	local player_style = managers.blackmarket:equipped_player_style()
	if armor_level >= 5 and EDAH._settings[player_style] and EDAH._settings[player_style]==true then
		
		camera_unit:spawn_manager():spawn_and_link_unit( "_char_joint_names", "armour_mesh", fps_armor ) --a_weapon_left
		EDAH.camera_unit = camera_unit
		EDAH.fancy_fps_armor_unit = camera_unit:spawn_manager():get_unit("armour_mesh")
		
		-- If our level ins't high enough for forearm armour than hide it.
		if armor_level <= 6 then
			EDAH.fancy_fps_armor_unit:get_object( Idstring( "g_vest_leg_arm" ) ):set_visibility( false )
		end
		
		-- If we have a skin we want to apply it.
		if skin_data and not skin_data.ignore_cc then
			self:_apply_skin(skin_data, armor_level )
		end
		
		Hooks:PostHook( PlayerStandard, "_start_action_steelsight", "EdwardArmorHands_start_action_steelsight", function( self )
			if managers and managers.player and managers.player:player_unit() and managers.player:player_unit():camera() and managers.player:player_unit():camera():camera_unit() then
				if EDAH and EDAH.fancy_fps_armor_unit and EDAH.fancy_fps_armor_unit:get_object( Idstring( "g_vest_shoulder" ) ) then
					DelayedCalls:Remove( "EdwardArmorHands_end_action_steelsight" )
					EDAH.fancy_fps_armor_unit:get_object( Idstring( "g_vest_shoulder" ) ):set_visibility( false )
				end
			end
		end)

		Hooks:PostHook( PlayerStandard, "_end_action_steelsight", "EdwardArmorHands_end_action_steelsight", function( self )
			local function dis()
				if managers and managers.player and managers.player:player_unit() and managers.player:player_unit():camera() and managers.player:player_unit():camera():camera_unit() then
					if EDAH and EDAH.fancy_fps_armor_unit and EDAH.fancy_fps_armor_unit:get_object( Idstring( "g_vest_shoulder" ) ) then
						EDAH.fancy_fps_armor_unit:get_object( Idstring( "g_vest_shoulder" ) ):set_visibility( true )
					end
				end
			end
			DelayedCalls:Add( "EdwardArmorHands_end_action_steelsight", 0.15, dis )
		end)
	end
end

function PlayerMovement:_applyExtraArmorSkin()
	-- Get the camera unit.
	local camera_unit = self._unit:camera():camera_unit()
	if not camera_unit then return end
	local cosmetics_id = managers.blackmarket:equipped_armor_skin()
	local armor_level = tweak_data.blackmarket.armors[managers.blackmarket:equipped_armor()].upgrade_level
	local character_name = managers.criminals:character_name_by_unit( self._unit )
	
	-- Get the skins data.
	local skin_data = managers.blackmarket:get_extra_armor_skin_data( cosmetics_id, armor_level, character_name )
	if skin_data then
		local function apply_extra_armor()
			self:_attach_fps_default_armour( camera_unit, armor_level, skin_data )
		end

		-- For some reason overkill has made certain parts of the sequence manager delayed so this is here so it runs after all of that. Also needs a unique name otherwise multiplayer has issues.
		DelayedCalls:Add( "EdwardArmorHands_FP_BodyStuff_" .. character_name, 0.5, apply_extra_armor )
	end
end

Hooks:PostHook( PlayerMovement, "set_character_anim_variables", "EdwardArmorHands_FPGame_SpawnArmour", function( self )
	self:_applyExtraArmorSkin()
end)