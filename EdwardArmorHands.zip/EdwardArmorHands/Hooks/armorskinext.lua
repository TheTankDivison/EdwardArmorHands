-- Make sure assets exist before loading them to reduce crashes.
local function safe_load( path, ext )
	-- Does it exist?
	if managers.dyn_resource and DB:has( ext, path ) then
		-- Load it.
		managers.dyn_resource:load( Idstring(ext), Idstring(path), DynamicResourceManager.DYN_RESOURCES_PACKAGE, false )

		-- Success!
		return true
	end

	-- Failure!
	return false
end

-- Make sure assets exist before unloading them to reduce crashes.
local function safe_unload( path, ext )
	-- Does it exist?
	if managers.dyn_resource and DB:has( ext, path ) then
		-- Unload it.
		managers.dyn_resource:unload( Idstring(ext), Idstring(path), DynamicResourceManager.DYN_RESOURCES_PACKAGE, false )

		-- Success!
		return true
	end

	-- Failure!
	return false
end

-- Setup default values.
EDAH.lastArmorUnitPath = ""
EDAH.lastArmorUnit = nil

-- Fancy armour function.
function EDAH:_apply_extra_armor_skin()
	-- Get the character name.
	local character_name = managers.criminals:character_name_by_unit( self._unit )
	-- Get skin data with any overrides applied.
	local skin_data = managers.blackmarket:get_extra_armor_skin_data( self._cosmetics_id, self:armor_level(), character_name )

	if skin_data then
		local function apply_extra_armor()
			local hide_armor = skin_data.hide_armor
			local replace_body = skin_data.replace_body
			local armour_unit = skin_data.unit

			-- Do we want to hide the armour?
			if hide_armor then
				-- If we do then run the base suit sequence.
				self._unit:damage():run_sequence_simple( "var_model_01" )
			else
				-- If not find out what armour we do want and run it's sequence.
				local sequence = tweak_data.blackmarket.armors["level_" .. self:armor_level()].sequence
				self._unit:damage():run_sequence_simple( sequence )
			end

			-- Do we want to replace the body?
			if replace_body then
				-- If we do then tell the sequence manager.
				self._unit:damage():set_variable( "var_body_replace", 1 )
			else
				-- If we don't then make sure the sequence manager knows that as well.
				self._unit:damage():set_variable( "var_body_replace", 0 )
			end

			-- Find out the characters base sequence.
			local sequence = managers.blackmarket:character_sequence_by_character_name( character_name )
			-- Check if it exists.
			if sequence then
				-- Re-run it with our new variables and armor.
				self._unit:damage():run_sequence_simple(sequence)
			end

			-- Check if this is the first armour unit or if we don't need a unit at all.
			if self.lastArmorUnit == nil or not armour_unit then
				-- Remove any attached meshes.
				self._unit:spawn_manager():remove_unit_nosync( "char_mesh" )

				-- If we're removing an armour unit then unload it and reset it's variables.
				if not armour_unit then
					safe_unload( self.lastArmorUnitPath, "unit" )
					self.lastArmorUnitPath = ""
					self.lastArmorUnit = nil
				end
			end

			-- If we have a skin unit.
			if armour_unit then
				-- If we're not using the same unit.
				if self.lastArmorUnitPath ~= armour_unit then
					-- Delete old one.
					self._unit:spawn_manager():remove_unit_nosync( "char_mesh" )

					-- Attempt to unload old one.
					safe_unload( self.lastArmorUnitPath, "unit" )
					-- Load new one and store if it was succesful.
					loaded = safe_load( armour_unit, "unit" )

					-- Store the path for future reference.
					self.lastArmorUnitPath = armour_unit

					-- If it succesfully loaded.
					if loaded then
						-- Spawn it and then store it for future reference.
						self.lastArmorUnit = self._unit:spawn_manager():spawn_and_link_unit_nosync_ret( "_char_joint_names", "char_mesh", armour_unit )
					end
				end
				
				-- If we have a valid attached unit.
				if self.lastArmorUnit ~= nil and alive( self.lastArmorUnit ) then
					-- Get the units material from the skin.
					local unit_material = skin_data.unit_material
					-- If it does have a material.
					if unit_material then
						-- Set the material.
						self.lastArmorUnit:set_material_config( Idstring( unit_material ), true )
					end

					-- Get any armour specific objects.
					local unit_objects = skin_data.unit_objects
					-- If we have some objects.
					if unit_objects then
						-- For each object and their state.
						for object, state in pairs( unit_objects ) do
							-- Show or hide them depending on their state.
							local found = self.lastArmorUnit:get_object( Idstring( object ) )
							-- Make sure they exist.
							if found then
								-- Set their visibility.
								found:set_visibility( state )
							end
						end
					end
				end
			end
		end

		-- For some reason overkill has made certain parts of the sequence manager delayed so this is here so it runs after all of that. Also needs a unique name otherwise multiplayer has issues.
		DelayedCalls:Add( "LegendaryArmourSkins_TP_BodyStuff_" .. character_name, 0.5, apply_extra_armor )
	end
end

Hooks:PreHook( EDAH, "_apply_cosmetics", "LegendaryArmourSkins_Game_SpawnArmour", function( self )
	-- Setup the heist_outfit default state.
	local heist_outfit = false

	-- Look for our current level id.
	local current_level = managers.job and managers.job:current_level_id()

	-- Make sure we have a valid value.
	if current_level then
		-- Find the levels player_sequence.
		local player_sequence = tweak_data.levels[current_level] and tweak_data.levels[current_level].player_sequence
		-- If the heist has a player_sequence ...
		if player_sequence then
			-- ... then it has an outfit.
			heist_outfit = true
		end
	end

	-- If we don't have a heist outfit, or we want to ignore the
	if not heist_outfit or LA_Skins.Options:GetValue("IgnoreHeistOutfits") then
		self:_apply_extra_armor_skin()
	end
end)