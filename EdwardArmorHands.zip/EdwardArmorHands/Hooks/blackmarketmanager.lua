function BlackMarketManager:get_extra_armor_skin_data( skin_id, level, character_id )
	local skin_data = tweak_data.economy.armor_skins[skin_id]
	if not skin_data then return nil end

	skin_data = deep_clone(skin_data)

	if skin_data.level_override and skin_data.level_override[level] then
		local level_skin_data = skin_data.level_override[level]

		for key, value in pairs(level_skin_data) do
			skin_data[key] = value
		end
	end

	if skin_data.character_override and skin_data.character_override[character_id] then
		local character_skin_data = skin_data.character_override[character_id]

		for key, value in pairs(character_skin_data) do
			skin_data[key] = value
		end
	end

	return skin_data
end