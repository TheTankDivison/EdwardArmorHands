EDAH = EDAH or class()


function EDAH:Init()

end