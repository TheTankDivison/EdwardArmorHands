EDAH = EDAH or class()
EDAH.save_path = SavePath .. "EDAHConfig.json"

EDAH.mod_path = 'mods\\EdwardArmorHands\\'
EDAH.ModOptions = EDAH.mod_path .. 'loc\\modoptions.txt'
Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_EDAH", function(loc)
    for __, filename in pairs(file.GetFiles(EDAH.mod_path .. "loc/")) do
		local str = filename:match('^(.*).json$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			loc:load_localization_file(EDAH.mod_path .. "loc/" .. filename)
			break
		end
    end
	
    loc:load_localization_file(EDAH.mod_path .. "loc/english.json", false)
end)

local function AddModOptions(menu_manager)
    if menu_manager == nil then
		return
    end

    MenuCallbackHandler.callback_EDAH_button = function(self, item)
		EDAH._menu:enable()
    end
	MenuHelper:LoadFromJsonFile(EDAH.ModOptions, EDAH)
end

Hooks:Add("MenuManagerInitialize", "EDAH_AddModOptions", AddModOptions)

function EDAH:Init()
	EDAH._settings={}
	EDAH:load_settings()
	EDAH:MainMenuInit()
	--tweak_data.blackmarket.player_styles[player_style]
	--managers.blackmarket:equipped_player_style()
end

function EDAH:save_settings()
	
	local file = io.open(EDAH.save_path, "w+")
	if file then
		file:write(json.encode(EDAH._settings))
		file:close()
	end
end

function EDAH:load_settings()
	local file = io.open(EDAH.save_path, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all")) or {}) do
			EDAH._settings[k] = v
		end
		file:close()
		return true
	else
		return false
	end
end

function EDAH:MainMenuInit()
	MenuUI:new({
		name = "EDAH",
		background_blur=true,
		layer = 1150,
		create_items = callback(self, self, "CreateNewbieMainMenu"),
		toggle_clbk = callback(self, self, "ShowNewbieMainMenu"),
		use_default_close_key = true
	})
	
end

function EDAH:CreateNewbieMainMenu(menu)
	EDAH._menu = menu
	local accent = Color(1, 1, 1)
	 EDAH._holder = EDAH._menu:DivGroup({
        name = "Edward Armor Hands",
        w = 400,
        auto_height = false,
        size = 20,
        background_visible = true,
        border_bottom = true,
        border_center_as_title = true,
        border_position_below_title = true,
        private = {text_align = "center"},
        border_lock_height = true,
        accent_color = accent,
        border_width = 200,
        background_color = Color('404040'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	EDAH._holder:Divider({ name = "Welcome", text_align = "center", text = "Enable armour on this suits:" })
	EDAH._holder:Toggle({
				name = "none",
				text = managers.localization:text(tweak_data.blackmarket.player_styles.none.name_id),
				value = EDAH._settings.none,
				on_callback = function(item)
					EDAH._settings[item:Name()] = item:Value()
					EDAH:save_settings()
				end
			})
	for id, value in pairs(tweak_data.blackmarket.player_styles or {}) do
		if id ~= "none" then
			EDAH._holder:Toggle({
				name = id,
				text = managers.localization:text(value.name_id),
				value = EDAH._settings[id],
				on_callback = function(item)
					EDAH._settings[item:Name()] = item:Value()
					EDAH:save_settings()
					if managers and managers.player and managers.player:player_unit() and managers.player:player_unit():camera() and managers.player:player_unit():camera():camera_unit() then
						local player_style = managers.blackmarket:equipped_player_style()
						if item:Name()==player_style then
							if item:Value() == true and EDAH.fancy_fps_armor_unit==nil then
								managers.player:player_unit():movement():_applyExtraArmorSkin()
							else
								if EDAH.fancy_fps_armor_unit then
									EDAH.camera_unit:spawn_manager():remove_unit("armour_mesh")
									
									EDAH.fancy_fps_armor_unit=nil
								end
							end
						end
					end
				end
			})
		end
	end
end

function EDAH:ShowNewbieMainMenu(menu, opened)
	if opened then
		if managers.player:player_unit() then
			game_state_machine:current_state():set_controller_enabled(false)
		end
    else
		game_state_machine:current_state():set_controller_enabled(true)
        EDAH._menu:disable()
    end
end